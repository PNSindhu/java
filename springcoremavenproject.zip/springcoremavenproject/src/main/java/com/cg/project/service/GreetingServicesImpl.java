package com.cg.project.service;

import org.springframework.stereotype.Component;
@Component("greetingServices")
public class GreetingServicesImpl implements GreetingServices{
	public void sayHello(String personName){
		System.out.println("Hello"+personName);
	}
	public void sayGoodBye(String personName){
	System.out.println("GoodBye"+personName);	
	}
}