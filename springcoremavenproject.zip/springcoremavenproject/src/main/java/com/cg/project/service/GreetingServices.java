package com.cg.project.service;
public interface GreetingServices {
	public void sayHello(String string);
	public void sayGoodBye(String string);

}
