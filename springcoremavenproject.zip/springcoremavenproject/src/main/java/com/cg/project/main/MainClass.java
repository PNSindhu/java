package com.cg.project.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.project.service.GreetingServices;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		GreetingServices greetingServices=(GreetingServices)applicationContext.getBean("greetingServices");
				greetingServices.sayHello("Sindhu");
				greetingServices.sayGoodBye("Sindhu");
    }
}
