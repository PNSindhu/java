package com.cg.banking.daoservices;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;


import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

@Component("bankingDaoSerives")
public class BankingDAOServicesImpl<SessionFactory> implements BankingDAOServices {
	@Autowired
	
	private EntityManagerFactory entityManagerFactory;

	@Override
	public long insertAccount(int customerId, Account account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer= entityManager.find(Customer.class, customerId);
		System.out.println(customer);
		if(customer!=null){
		account.setCustomer(customer);
		entityManager.persist(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return account.getAccountNo();
		}
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		if(account.getCustomer().getCustomerId()==customerId){
		entityManager.merge(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
		}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		if(account.getCustomer().getCustomerId()==customerId){
			account.setPinNumber(BankingUtility.random.nextInt(9999));
			updateAccount(customerId, account);
			return account.getPinNumber();
		}
			
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Account account= (Account) entityManager.find(Account.class, accountNo);
		System.out.println(account);
		if(account!=null){
		transaction.setAccount(account);
		entityManager.persist(transaction);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		}
		return true;
	}
	

	@Override
	public boolean deleteCustomer(int customerId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Customer customer=entityManager.find(Customer.class,customerId);
		if(customer!=null){
			entityManager.getTransaction().begin();
			entityManager.remove(customer);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;
		}
				return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
	Account account=entityManager.find(Account.class,accountNo);
			entityManager.getTransaction().begin();
			entityManager.remove(account);
			entityManager.flush();
			entityManager.getTransaction().commit();
			entityManager.close();
			return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Customer customer=entityManager.find(Customer.class,customerId);
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Account account=entityManager.find(Account.class,accountNo);
		return account;
	
	}

	@Override
	public List<Customer> getCustomers() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		javax.persistence.TypedQuery<Customer> query =  entityManager.createQuery("Select c from Customer c",Customer.class);
		return query.getResultList();
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		javax.persistence.TypedQuery<Account> query =  entityManager.createQuery("Select a from Account a",Account.class);
		return query.getResultList();

	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		javax.persistence.TypedQuery<Transaction> query =  entityManager.createQuery("Select t from Transaction t",Transaction.class);
		return query.getResultList();

	}

	@Override
	public boolean updateCustomer(Customer customer) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	
	@Override
	public Customer[] getcustomer() {
		return null;
	}

	@Override
	public int insertCustomer(Customer customer) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer.getCustomerId();
	
	}

	@Override
	public float balanceEnquiry(int customerId, long accountNo, int pinNumber) {
		return 0;
	}

	@Override
	public Customer getcustomer(int customerId) {
		return null;
	}
}