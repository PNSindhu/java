package com.cg.example;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RoyalEnfield {

	public static void main(String[] args) {
		try{
			System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("http://www.google.com");
			
			WebElement searchField=driver.findElement(By.id("lst-ib"));
			searchField.sendKeys("royalenfield");
			searchField.submit();
			
			WebElement imagesLink=driver.findElements(By.linkText("Images")).get(0);
			imagesLink.click();
			WebElement toolLink=driver.findElements(By.linkText("Tools")).get(0);
			toolLink.click();
			WebElement colorLink=driver.findElements(By.linkText("color")).get(1);
			colorLink.click();
			
			WebElement imageElement=driver.findElements(By.cssSelector("a[class=srp tbo vasq]")).get(0);
			
			WebElement colourLink=driver.findElements(By.linkText("Black and White")).get(2);
			colourLink.click();
			WebElement colourElement=driver.findElements(By.cssSelector("a[class=q qs]")).get(0);

			

	}finally {}

}
}
