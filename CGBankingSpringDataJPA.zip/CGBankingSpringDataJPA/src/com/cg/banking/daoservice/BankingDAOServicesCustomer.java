package com.cg.banking.daoservice;


public interface BankingDAOServicesCustomer{

	Object findOne(int customerId);

}
