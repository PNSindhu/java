package com.cg.banking.beans;

import java.util.HashMap;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
@Entity
public class Account {
	private int pinNumber,pinCounter;
	private String accountType,status;
	private float accountBalance,initBalance;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	private long accountNo;	
	private HashMap<Integer,Transaction>Transactions=new HashMap<Integer,Transaction>();
	public Account() {}
	
	public Account(int pinNumber, int pinCounter, String accountType, String status, float accountBalance,
			long accountNo) {
		super();
		this.pinNumber = pinNumber;
		this.pinCounter = pinCounter;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
	}

	public Account(int pinNumber, int pinCounter, String accountType, String status, float accountBalance,
			long accountNo, HashMap<Integer, Transaction> transactions) {
		super();
		this.pinNumber = pinNumber;
		this.pinCounter = pinCounter;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		Transactions = transactions;
	}

	public Account(String accountType, float initBalance) {
		super();
		this.accountType = accountType;
		this.initBalance = initBalance;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public int getPinCounter() {
		return pinCounter;
	}

	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public HashMap<Integer, Transaction> getTransactions() {
		return Transactions;
	}

	public void setTransactions(HashMap<Integer, Transaction> transactions) {
		Transactions = transactions;
	}

	public Integer getTRANSACTION_ID_COUNTER() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	public Customer getCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

}