package com.cg.banking.daoservices;

public interface BankingDAOServicesTransaction {

}
