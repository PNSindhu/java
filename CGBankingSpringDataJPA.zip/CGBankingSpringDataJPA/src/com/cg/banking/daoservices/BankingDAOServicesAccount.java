package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;

public interface BankingDAOServicesAccount {

	void save(Account account);

}
