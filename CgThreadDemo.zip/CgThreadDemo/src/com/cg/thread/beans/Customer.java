package com.cg.thread.beans;
import com.cg.thread.beans.Account;
public class Customer implements Runnable {

	public Customer() {
		super();
	}
	private static Account account;
	static{
		account=new Account(10000);
		System.out.println("Initial Balance:"+account.getBalance()+"\n\n==========================");
	}

	@Override
	public void run() {
		Thread customerThread=Thread.currentThread();
		if(customerThread.getName().equals("Sindhu")){
			for(int i=1;i<10;i++){
				try{
					Thread.sleep(0);
					System.out.println("|n Sindhu has call Withdraw()"+i +"time balance:="+account.withdraw(3000));
				}catch(InterruptedException e){
						e.printStackTrace();
					}
				}
			}
			if(customerThread.getName().equals("Chakri")){
				for(int i=0;i<10;i++){
					try{
						Thread.sleep(0);
						System.out.println("\n Chakri has call deposit()"+i +"time balance:="+account.deposit(2000));
					}catch(InterruptedException e){
							e.printStackTrace();
						}
					}
				}
			if(customerThread.getName().equals("Deepu")){
				for(int i=0;i<=3;i++){
					System.out.println("\n Deepu has call getBalance()"+i +"time balance:="+account.getBalance());
					}
				}
			}
			
		}


