package com.cg.thread;

public class RunnableResource implements Runnable{
	public RunnableResource() {
		super();
	}

	@Override
	public void run() {
		Thread t=Thread.currentThread();
		if(t.getName().equals("thread-1"));
		for(int i=0;i<100;i++)
			if(i%2==0)
			System.out.println(i);

		else if(t.getName().equals("thread-0"))
			//for(int j=0;j<100;j++)
			if(i%2!=0)
			System.out.println(i);
		System.out.println("Hello World");

	}

}
