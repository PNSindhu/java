package com.cg.thread.main;

import com.cg.thread.MyThread;
import com.cg.thread.RunnableResource;
import com.cg.thread.beans.Customer;

public class MainClass {

	public static void main(String[] args) {
		RunnableResource resource=new RunnableResource();
		Thread th1=new Thread(new Customer(),"Sindhu");
		Thread th2=new Thread(new Customer(),"Chakri");
		Thread th3=new Thread(new Customer(),"Deepu");
		//MyThread th1=new MyThread("thread-1");
		//MyThread th2=new MyThread("thread-0");
		th1.start();
		th2.start();
		th3.start();
	}

}
