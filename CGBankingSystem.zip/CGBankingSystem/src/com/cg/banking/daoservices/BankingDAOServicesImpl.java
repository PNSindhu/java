package com.cg.banking.daoservices;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;


public class BankingDAOServicesImpl implements BankingDAOServices {
	private static Customer[] customerList=new Customer[3];
	private static int CUSTOMER_ID_COUNTER=111;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static int TRANSACTION_ID=0001;
	private static int TRANSACTION_IDX=0;
	private static int ACCOUNT_NO=222;
	private static int ACCOUNT_NOX=0;

	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerId();
	} 

	@Override
	public boolean updateCustomer(Customer customer) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customer.getCustomerId()==customerList[i].getCustomerId()) {
				customerList[i]=customer;
				return true;
			}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerID) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerID==customerList[i].getCustomerId()) {
				customerList[i]=null;
				return true;
			}
		return false;
	}

	@Override
	public Customer getCustomer(int customerID) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerID==customerList[i].getCustomerId()) {
				return customerList[i];
			}
		return null;
	}
	@Override
	public Customer getcustomer(int customerId) {
		return null;
	}
	@Override
	public Customer[] getcustomer() {
		return null;
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
		for(int j=0;j<customerList.length;j++)	
			if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId&&customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo()){
				
			}
		account.setAccountNo(ACCOUNT_NO++);
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++) {
			for(int j=0;j<customerList[i].getAccounts().length;j++){
				if(customerList[i]!=null&&customerList[i].getCustomerId()==customerId&&customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo()){
				customerList[i].getAccounts()[j]=account;
				return true;
				}
				}
				customerList[i]=customerId;;
				return true;
			}
		return false;
	}
		
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		for(int i=0;i<customerList.length;i++)
				for(int j=0;j<customerList[i].getAccounts().length;j++)	
					for(int k=0;k<customerList[i].getTransaction().length;k++)
(customerList[i]!=null&&customerList[i].getCustomerId()==customerId&&customerList[i].getAccounts()[j].getAccountNo()==account.getAcccountNo()&&customerList[i].get){
						
						
				
		

		}
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()) {
				customerList[i]=null;
							
				return true;
		
		return false;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null&&customerId==customerList[i].getCustomerId()&&accountNo==customerList[i].getAccounts()) {
				return customerList[i];
			}
		
	
		return null;
	}

	@Override
	public Customer[] getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account[] getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		return null;
	}

}




	