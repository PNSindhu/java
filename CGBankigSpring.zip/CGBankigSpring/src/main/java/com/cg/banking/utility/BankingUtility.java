package com.cg.banking.utility;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=111;
	public static int TRANSACTION_ID_COUNTER=0001;
	public static long ACCOUNT_NO_COUNTER=1;


}
