package src.com.cg.payroll.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import src.com.cg.payroll.beans.Associate;
import src.com.cg.payroll.beans.BankDetails;
import src.com.cg.payroll.beans.Salary;
import src.com.cg.payroll.daoservices.PayrollDAOService;
import src.com.cg.payroll.services.AssociateDetailsNotFoundException;
import src.com.cg.payroll.services.PayrollServices;
import src.com.cg.payroll.services.PayrollServicesImpl;
import src.com.cg.payroll.utility.PayrollUtility;
public class PayrollServicesTest {
	private static PayrollServicesTest payrollServices;
	@BeforeClass
	public static void setUpTestEnv(){
	payrollServices=new PayrollServicesTest();
	}
	@Before
	public void setUpMockData(){
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
	Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER,115000, "Sindhu", "Pullela", "Training", "Sr con", "dhmk1", "sindhu@abc.com", new Salary(50000, 20, 40), new BankDetails(273478, "HDFC", "HDFC1234"));
	PayrollDAOServicesImpl.associates.put(PayrollUtility.ASSOCIATE_ID_COUNTER++,associate1);
	Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER,115000, "Chakri", "Pullela", "Training", "Sr con", "vsjhu1", "Chakri@abc.com", new Salary(50000, 20, 40), new BankDetails(273478, "AXIS", "AXIS1234"));
	PayrollDAOServicesImpl.associates.put(PayrollUtility.ASSOCIATE_ID_COUNTER++, associate2);
	Associate associate3=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER,115000, "Deppu", "Pullela", "Training", "Sr con", "vmiw1", "deepu@abc.com", new Salary(50000, 20, 40), new BankDetails(273478, "HDFC", "HDFC1234"));
	PayrollDAOServicesImpl.associates.put(PayrollUtility.ASSOCIATE_ID_COUNTER++, associate3);
	 }
	@Test
	public void  testAcceptAssociateDetailsForValidData(){
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidData()throws AssociateDetailsNotFoundException{
	}
	@Test
	public void testCalculateNetSalaryForValidData() throws AssociateDetailsNotFoundException{
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
		
	}
	@Test
	public void testGetAssociateDetailsForValidData()throws AssociateDetailsNotFoundException,PayrollServicesDownException{
	}
//@Test(expected=AssociateDetailsNotFoundException.class)
	//public void testGetAssociateDetailsForInvalidData()throws AssociateDetailsNotFoundException{
		//Assert.assertEquals(, actuals);
	//}
	@Test
	public void getAllAssociateDetails()throws AssociateDetailsNotFoundException{
	}
	@After
	public void tearDownMockData(){
		PayrollDAOServicesImpl.associates.clear();
	}
	@AfterClass
	public static void setUp(){
		
	}
}


	


