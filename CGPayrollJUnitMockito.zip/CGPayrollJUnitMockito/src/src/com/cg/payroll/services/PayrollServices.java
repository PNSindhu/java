package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;

public interface PayrollServices {
	public int acceptAssociateDetails(String firstName, String lastName,
			String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,float basicSalary,float epf,float companyPf,int accountNumber
			,String bankName, String ifscCode);

	public abstract int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException;
	public abstract Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException ;
	public abstract List<Associate> getAllAssociatesDetails();

	public boolean updateAssociateDetails(Associate associate);
}
