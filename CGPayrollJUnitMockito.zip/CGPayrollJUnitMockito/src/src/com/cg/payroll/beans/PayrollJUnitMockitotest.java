package src.com.cg.payroll.beans;

import static org.junit.Assert.*;

import org.junit.Test;

public class PayrollJUnitMockitotest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
