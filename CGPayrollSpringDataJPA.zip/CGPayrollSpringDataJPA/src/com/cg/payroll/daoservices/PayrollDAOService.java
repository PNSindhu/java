package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.PayrollServicesDownException;

public interface PayrollDAOService extends JpaRepository<Associate,Integer>{

	Associate save(Associate associate);

	Associate getAssociate(int associateID);

	List<Associate> getAssociates();

	/*int insertAssociate(Associate associate) throws SQLException;

	boolean updateAssociate(Associate associate) throws PayrollServicesDownException, SQLException;

	boolean deleteAssociate(int associateID);

	Associate getAssociate(int associateID) throws PayrollServicesDownException, SQLException;

	List<Associate> getAssociates() throws SQLException;*/

}