package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public interface PayrollServices {
	public abstract int acceptAssociateDetails(String firstName, String lastName,
			String emailId,String department, String designation, String pancard,
			int yearlyInvestmentUnder80C,float basicSalary,float epf,float companyPf,int accountNumber
			,String bankName, String ifscCode);

	public abstract int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException;
	public abstract Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException;
	public abstract List<Associate> getAllAssociatesDetails();

	public boolean updateAssociateDetails(Associate associate);

	public static int acceptAssociateDetails(String string, String string2, String string3, String string4,
			String string5, String string6, Salary salary, BankDetails bankDetails) {
		return 0;
	}
}
