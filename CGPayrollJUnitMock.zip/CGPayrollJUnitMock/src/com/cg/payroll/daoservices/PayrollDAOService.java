package com.cg.payroll.daoservices;

import java.util.List;

import com.cg.payroll.beans.Associate;

public interface PayrollDAOService {

	int insertAssociate(Associate associate);

	boolean updateAssociate(Associate associate);

	boolean deleteAssociate(int associateID);

	Associate getAssociate(int associateID);

	List<Associate> getAssociates();

}