package com.cg.payroll.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.daoservices.PayrollDAOService;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

public class MainClass {

	public static void main(String[] args)throws PayrollServicesDownException{

		PayrollDAOService daoServices=new PayrollDAOServicesImpl();
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices)applicationContext.getBean("payrollServices");
	}
}
/*try{
			PayrollUtility.getDBConnection();
			System.out.println("Connection Open");			
		}catch(PayrollServicesDownException e){
			e.printStackTrace();
		}
	}
}*/
/*PayrollServices payrollServices=new PayrollServicesImpl();
		PayrollDAOServicesImpl daoServices = new PayrollDAOServicesImpl();
		int choice=0;
		do {
			Scanner scan = new Scanner(System.in);
			try {
				System.out.println("MENU:");
				System.out.println("\t 1. Registration of Employee");
				System.out.println("\t 2. Calculate NetSalary ");
				System.out.println("\t 3. Update Details of Employee");
				System.out.println("\t 4. Get Associate Details  ");
				System.out.println("\t 5. Get All Associate Details ");
				System.out.println("\t 6. Exit");
				System.out.print("Enter your choice: ");
				choice=scan.nextInt();
				switch(choice) {
				case 1 :
					System.out.print("\t Enter FirstName: ");
					String  firstName = scan.next();
					System.out.print("\t Enter LastName: ");
					String lastName = scan.next();
					System.out.print("\t Enter Email-ID:  ");
					String emailId = scan.next();
					System.out.print("\t Enter Department Name: ");
					String department=scan.next();
					System.out.println("\t Enter Designation:");
					String designation=scan.next();
					System.out.println("\t Enter PAN Number: ");
					String pancard = scan.next();
					System.out.println("\t Enter YearlyInvestment Under80C Amount : ");
					int yearlyInvestmentUnder80C=scan.nextInt();
					System.out.println("\t Enter Basic Salary: ");
					int basicSalary=scan.nextInt();
					System.out.println("\t Enter EPF : ");
					int epf=scan.nextInt();
					System.out.println("\t Enter CompanyPF : ");
					int companyPf=scan.nextInt();
					System.out.println("\t Enter AccountNo : ");
					int accountNumber=scan.nextInt();
					System.out.println("\t Enter  BankName : ");
					String bankName=scan.next();
					System.out.println("\t Enter  Bank IFSC Code : ");
					String ifscCode=scan.next();
					int associateIDcase1=payrollServices.acceptAssociateDetails(firstName, lastName, emailId, department, designation, pancard, yearlyInvestmentUnder80C, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode);
					System.out.println("The generated AssociateID is : "+ associateIDcase1);
					break;
				case 2:
					System.out.println("\t Enter AssociateID : ");
					int assocaiteIDcase2=scan.nextInt();
					int netSalaryCase2=payrollServices.calculateNetSalary(assocaiteIDcase2);
					System.out.println("\t The NetSalary is : "+netSalaryCase2+",for AssociateID : "+assocaiteIDcase2);
					break;
				case 3:
					System.out.println("\t Enter AssociateID : ");
					int assocaiteIDcase3=scan.nextInt();
					System.out.print("\t Enter FirstName: ");
					String  firstNamecase3 = scan.next();
					System.out.print("\t Enter LastName: ");
					String lastNamecase3 = scan.next();
					System.out.print("\t Enter Email-ID:  ");
					String emailIdcase3 = scan.next();
					System.out.print("\t Enter Department Name: ");
					String departmentcase3=scan.next();
					System.out.print("\t Enter Designation:");
					String designationcase3=scan.next();
					System.out.print("\t Enter PAN Number: ");
					String pancardcase3 = scan.next();
					System.out.println("\t Enter YearlyInvestment Under80C Amount : ");
					int yearlyInvestmentUnder80Ccase3=scan.nextInt();
					System.out.println("\t Enter Basic Salary: ");
					int basicSalarycase3=scan.nextInt();
					System.out.println("\t Enter EPF : ");
					int epfcase3=scan.nextInt();
					System.out.println("\t Enter CompanyPF : ");
					int companyPfcase3=scan.nextInt();
					System.out.println("\t Enter AccountNo : ");
					int accountNumbercase3=scan.nextInt();
					System.out.println("\t Enter  BankName : ");
					String bankNamecase3=scan.next();
					System.out.println("\t Enter  Bank IFSC Code : ");
					String ifscCodecase3=scan.next();
					boolean acase3= payrollServices.updateAssociateDetails(new Associate(assocaiteIDcase3, yearlyInvestmentUnder80Ccase3, firstNamecase3, lastNamecase3, departmentcase3, designationcase3, pancardcase3, emailIdcase3, new Salary(basicSalarycase3, epfcase3, companyPfcase3), new BankDetails(accountNumbercase3, bankNamecase3, ifscCodecase3)));
					System.out.println("\t Details Updated : "+acase3);
					break;
				case 4:
					System.out.println("\t Enter AssociateID : ");
					int assocaiteIDcase4=scan.nextInt();
					Associate acase4=payrollServices.getAssociateDetails(assocaiteIDcase4);
					System.out.println("\t Details of Associate ID "+assocaiteIDcase4+" : "+acase4);
					break;
				case 5:
					payrollServices.getAllAssociatesDetails();
					System.out.println("All Associate Details : ");
					break;
				case 6:
					System.out.println("You are go to Exit,Thank You!!!");
				default:
					System.out.println("Please Enter Valid Option!!!");
					break;
				}
			} catch (AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}

		}while(choice!=6);

		try {
			int associateID0=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID0);
			int associateID1=payrollServices.acceptAssociateDetails("a", "c", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID1);
			int associateID2=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID2);
			int associateID3=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID3);
			int associateID4=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID4);
			int associateID5=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID5);
			int associateID6=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID6);
			int associateID7=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID7);
			int associateID8=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID8);
			int associateID9=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID9);
			int associateID10=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID10);

			int associateID11=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID11);
			int associateID12=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID12);
			System.out.println(daoServices.getAssociate(160));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public static Associate associateSearch() {
	Associate associates[]=new Associate[4];
	associates[0]=new Associate(123, 100000, "Satish", "Mahajan", "Training", "Sr Con", "S1", "satish@abcd.com", new Salary(50000, 10, 20, 30, 40, 50, 10, 10, 10, 60000, 70000),new BankDetails(1234, "hdfc", "hdfc1"));
	associates[1]=new Associate(124, 30000, "abhi", "c", "tech", "dev", "a1","abhi@abcd.com",new Salary(55000, 10, 20, 30, 40, 50, 10, 10, 10, 65000, 70700), new BankDetails(1235, "sbi", "sbi1"));
	for(Associate associate:associates) {
		if( associate!=null && associate.getFirstName()=="Satish"&&associate.getYearlyInvestmentUnder80C()>50000&&associate.getSalary().getBasicSalary()==60000) 
			return associate;
	}
	return null;
}*/





/*	Associate [] associates=new Associate[3];
		PayrollServicesImpl payrollServices=new PayrollServicesImpl();
		int associateID=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 25000, 300000, 600, 100, 12345, "hdfc", "hdfc1");
		int associateID1=payrollServices.acceptAssociateDetails("Sindhu", "Pullela", "sindhu@abc.com", "hr", "sr", "as23", 50000, 500000, 20, 30, 123456, "axis", "axis123");
		int associateID2=payrollServices.acceptAssociateDetails("chakri", "S", "chakri@abc.com", "HR", "Senior", "sd34", 15000, 300000, 30, 40, 14567, "Axis", "axis34");
		int associateID3=payrollServices.acceptAssociateDetails("deepu", "P", "deepu@abc.com", "HR", "Senior", "sd34", 14000, 330000, 30, 40, 14567, "Axis", "axis34");
		int associateID4=payrollServices.acceptAssociateDetails("Sai", "P", "sai@abc.com", "HR", "Senior", "sd34", 14000, 330000, 30, 40, 14567, "Axis", "axis34");

		System.out.println(associateID);
		System.out.println(associateID2);
		System.out.println(associateID3);
		System.out.println(associateID4);
		try{
			System.out.println(payrollServices.calculateNetSalary(associateID));

		}catch(AssociateDetailsNotFoundException e){
			e.printStackTrace();
		}

		try {
			System.out.println("NetSalary" + " "+payrollServices.getAssociateDetails(associateID).getSalary().getAnnualSalary());
			System.out.println("BankName"+" "+payrollServices.getAssociateDetails(associateID).getBankdetails().getBankName());
			System.out.println(associateID1);

			System.out.println(payrollServices.calculateNetSalary(associateID1));
			System.out.println("Monthly TAx" + " "+payrollServices.getAssociateDetails(associateID1).getSalary().getMonthlyTax());
			System.out.println("NetSalary" + " "+payrollServices.getAssociateDetails(associateID1).getSalary().getAnnualSalary());
			System.out.println("BankName"+" "+payrollServices.getAssociateDetails(associateID1).getBankdetails().getBankName());

		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}*/


//int associateIdToBeSearched=111;




//Associate associate=associateSearch(associateIdToBeSearched);
/*Associate associate=associateSearch();
		if(associate!=null)
			System.out.println("Details Found");
		else
			System.out.println("Details Not found");*/

/*for(int i=0;i<5;i++) {
			associateList[i]=new Associate[3];
			for(int j=0;j<3;j++) {
				associateList[i][j]=new Associate();
			}
		}

		Associate associate = new Associate(123, 25, "abi", "c", "hr", "chief", "a1", "abi@abcd.com");
		BankDetails bankdetails=new BankDetails(12345, "hdfc", "1234");
		Salary salary=new Salary(1000, 10, 11, 12, 13, 14, 15, 16, 17, 1014, 920);
		System.out.print(" AssociateID: "+associate.getAssociateID()
		+"\n YearlyInvestmentUnder80C: "+associate.getYearlyInvestmentUnder80C()
		+"\n FirstName: "+associate.getFirstName()
		+"\n LastName: "+associate.getLastName()
		+"\n Department: "+associate.getDepartment()
		+"\n Designation: "+associate.getDesignation()
		+"\n PanCard No: "+associate.getPancard()+"\n EmailId: "+associate.getEmailId());
System.out.print("\n Bank Account No: "+bankdetails.getAccountNumber()
		+"\n BankName: "+bankdetails.getBankName()
		+"\n IFSC CODE: "+bankdetails.getIfscCode());
System.out.print("\n Basic Salary: "+salary.getBasicSalary()
		+"\n hra:" +salary.getHra()
		+"\n ConveyenceAllowance: "+salary.getConveyenceAllowance()
		+"\n OtherAllowances: "+salary.getOtherAllowance()
		+"\n Personal Allowance: "+salary.getPersonalAllowance()
		+"\n Monthly Tax: " +salary.getMonthlyTax()
		+"\n EPF: "+salary.getEpf()
		+"\n CompanyPf: "+salary.getCompanyPf()
		+"\n Gratuity: "+salary.getGratuity()
		+"\n GrossSalary: "+salary.getGrossSalary()
		+"\n NetSalary: "+salary.getNetSalary());*/
//associatedisplay();

//}
//public static Associate associateSearch(int associateID) {
//public static Associate associateSearch() {
//public static void associatedisplay() {
//Associate associates[]=new Associate[4];
/*associates[0]=new Associate(123, 60000, "Satish", "c", "hr", "chief", "a1", "abi@abcd.com");
	associates[1]=new Associate(124, 25, "abi", "c", "hr", "chief", "a1", "abi@abcd.com");
	associates[2]=new Associate(125, 25, "abi", "c", "hr", "chief", "a1", "abi@abcd.com");
	for(Associate associate:associates) {
		if( associate!=null && associate.getFirstName()=="Satish"&&associate.getYearlyInvestmentUnder80C()>50000) 
			return associate;

	}
	return null;*/


//System.out.println(associates[0].getSalary().getBasicSalary();



