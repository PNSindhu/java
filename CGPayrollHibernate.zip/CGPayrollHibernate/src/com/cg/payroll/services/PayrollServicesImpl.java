package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOService;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.PayrollServicesDownException;


@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices{
	@Autowired
	private PayrollDAOService payrollDAOService;
		//private PayrollDAOService daoServices;
		//public PayrollServicesImpl() throws PayrollServicesDownException {
		//daoServices=new PayrollDAOServicesImpl();
		//}

		public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
				String designation, String pancard, int yearlyInvestmentUnder80C, float basicSalary, float epf,
				float companyPf, int accountNumber, String bankName, String ifscCode) throws SQLException {
				/*Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, panCard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
						daoServices.insertAssociate(associate);
							return associate.getAssociateID();*/
			return payrollDAOService.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
		}
		public int calculateNetSalary(int associateID) throws AssociateDetailsNotFoundException, PayrollServicesDownException, SQLException {
				Associate associate=this.getAssociateDetails(associateID);
				int taxAmount=0;
				if(associate!=null) {
					associate.getSalary().setPersonalAllowance((int)30*associate.getSalary().getBasicSalary()/100);
					associate.getSalary().setConveyenceAllowance((int)20 *associate.getSalary().getBasicSalary()/100);
					associate.getSalary().setOtherAllowance((int)10 *associate.getSalary().getBasicSalary()/100);
					associate.getSalary().setHra((int)(25/10) * associate.getSalary().getBasicSalary()/100);
					associate.getSalary().setGratuity((int) ((int)50 * associate.getSalary().getBasicSalary()/100));
					associate.getSalary().setGrossSalary((int) (associate.getSalary().getBasicSalary()+(associate.getSalary().getPersonalAllowance()+(associate.getSalary().getConveyenceAllowance()+(associate.getSalary().getOtherAllowance()+(associate.getSalary().getCompanyPf()+(associate.getSalary().getHra())))))));
					//associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-(associate.getSalary().getMonthlyTax()-(associate.getSalary().getEpf()-(associate.getSalary().getCompanyPf()))));
					int annualSalary= (int) (associate.getSalary().getGrossSalary()*12);
					int taxableSalary=annualSalary;
					int nonTaxableSalary=(int) (associate.getYearlyInvestmentUnder80C()+(associate.getSalary().getEpf()*12)+(associate.getSalary().getCompanyPf()*12));
					if(nonTaxableSalary>150000)
						nonTaxableSalary=150000;
					if(taxableSalary<=250000){
						taxAmount=0;
					}	
					else if(taxableSalary>250000 && taxableSalary<=500000){
						taxableSalary=taxableSalary-250000-nonTaxableSalary;
						if(taxableSalary<0)
							taxAmount=0;
						else
							taxAmount=taxableSalary*10/100;	
					}
					else if (taxableSalary>500000 && taxableSalary<=1000000){
						int taxSlab2=(500000-250000-nonTaxableSalary)*10/100;
						taxAmount=((taxableSalary-500000)*20/100)+taxSlab2;	
					}
					else if (taxableSalary>1000000){
						int taxSlab2=(500000-250000-nonTaxableSalary)*10/100;
						int taxSlab3=(500000)*20/100;
						taxAmount=((taxableSalary-1000000)*30/100)+taxSlab3+taxSlab2;	
					}
					associate.getSalary().setMonthlyTax((int)taxAmount/12);
					associate.getSalary().setNetSalary((int)(((annualSalary-taxAmount)/12)-associate.getSalary().getCompanyPf()-associate.getSalary().getEpf()));
					return associate.getSalary().getNetSalary() ;
				}
				return 0;
			}
		@Override
		public Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException, PayrollServicesDownException, SQLException {
		Associate associate=payrollDAOService.getAssociate(associateID);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("associate details of AssociateID"+associateID+"not found");
		return payrollDAOService.getAssociate(associateID);
	}
		@Override
		public List<Associate> getAllAssociatesDetails() throws SQLException {
			return payrollDAOService.getAssociates();
		}
		@Override
		public boolean updateAssociateDetails(Associate associate) {
			return false;
		}
}
		/*if(associate.getSalary().getBasicSalary()>0&&associate.getSalary().getBasicSalary()<=250000)
						taxAmount=0;
					if(associate.getSalary().getBasicSalary()>250000&&associate.getSalary().getBasicSalary()<=500000){
							amt=(associate.getSalary().getGrossSalary()-250000-(associate.getSalary().getEpf()+(associate.getSalary().getCompanyPf()+associate.getYearlyInvestmentUnder80C())));
							taxAmount=(float)(0.1)*amt;
							associate.getSalary().setAnnualTax(taxAmount);
							associate.getSalary().setMonthlyTax(associate.getSalary().getAnnualTax()/12);
							return associate.getSalary().getAnnualTax();
						}
						if(associate.getSalary().getBasicSalary()>500000&&associate.getSalary().getBasicSalary()>=1000000){
								amt=(associate.getSalary().getBasicSalary()-250000-(associate.getSalary().getEpf()+(associate.getSalary().getCompanyPf()+(associate.getYearlyInvestmentUnder80C()))));
								taxAmount=(float)(0.2)*amt;
								associate.getSalary().setAnnualTax(taxAmount);
								associate.getSalary().setMonthlyTax(associate.getSalary().getAnnualTax()/12);
								return associate.getSalary().getAnnualTax();
							}
				}
				return 0;
			}

		public Associate getAssociateDetails(int associateID) throws AssociateDetailsNotFoundException {
			Associate associate=daoServices.getAssociate(associateID);
			if(associate==null)
				throw new AssociateDetailsNotFoundException("associate details of AssociateID"+associateID+"not found");
			return daoServices.getAssociate(associateID);
		}
		public List<Associate> getAllAssociatesDetails() {
			// TODO Auto-generated method stub
			return daoServices.getAssociates();
		}
		public Associate getAssociateDetails() throws AssociateDetailsNotFoundException {
			// TODO Auto-generated method stub
			return null;
		}

		

		
		
		}*/
		



