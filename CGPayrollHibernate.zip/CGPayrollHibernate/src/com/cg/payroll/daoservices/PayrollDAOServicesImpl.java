package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
@Component("payrollDaoServices")
public class PayrollDAOServicesImpl implements  PayrollDAOService {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		Session session=sessionFactory.openSession();
		Integer associateId=(Integer)session.save(associate);
		try {
			((Transaction) session).commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
		return 0;
	}

	@Override
	public boolean updateAssociate(Associate associate) throws PayrollServicesDownException, SQLException {
				return false;
	}

	@Override
	public boolean deleteAssociate(int associateID) {
		return false;
	}

	@Override
	public Associate getAssociate(int associateID) throws PayrollServicesDownException, SQLException {
		return null;
	}

	@Override
	public List<Associate> getAssociates() throws SQLException {
		return null;
	}
}
