package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
public class MainClass {
	public static void main(String[] args) {
	Associate associate1= new Associate(11, 15000, "kshitij", "mehrotra", "mf", "analyst", "sssss", "abc@gmail.com"); 
			System.out.println();
	
	}
	

}
