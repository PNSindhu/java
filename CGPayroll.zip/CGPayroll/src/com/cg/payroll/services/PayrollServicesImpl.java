package com.cg.payroll.services;
import  com.cg.payroll.beans.Associate;
public class PayrollServicesImpl {
	
	public int acceptAssociateDetails(int yearlyInvestmentUnder80C, String firstName, String lastName,
									String department, String designation, String pancard, String emailId,
									int basicSalary,int epf,int companyPf,int accountNo,String bankName,String ifscCode){
	return 0;	
	}	
public int calculateNetSalary(int associateId){
	return 0;
}
public Associate getAssociateDetails(int associateId){
	return null;
}
public Associate[]getAllAssociatesDetails(){
	return null;
}
}
