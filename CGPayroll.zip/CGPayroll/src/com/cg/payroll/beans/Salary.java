package com.cg.payroll.beans;

public class Salary {

}
