package com.cg.banking.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;

public class BankingServicesTest {

	private static BankingServices bankingServices;
	@BeforeClass
	public static void setUpTestEnv(){
		bankingServices=new BankingServicesImpl();
		}
	@Before
	public void setUpMockData(){
		BankingUtility.CUSTOMER_ID_COUNTER=111;
		BankingUtility.ACCOUNT_NO_COUNTER=11111111;
		BankingUtility.TRANSACTION_ID_COUNTER=0001;
		BankingDAOServicesImpl.customers.put(BankingUtility.CUSTOMER_ID_COUNTER++,new Customer("Sindhu", "Pullela", "sindhu@abc.com", "syfgi", new Address(1334, "crl", "Ap"),new Address(1234, "Hyd", "Tel")));
		//BankingDAOServicesImpl.customers.get(BankingUtility.CUSTOMER_ID_COUNTER).getAccounts().put(BankingUtility.ACCOUNT_NO_COUNTER,new Account("Savings", 500));
		//BankingDAOServicesImpl.customers.get(BankingUtility.CUSTOMER_ID_COUNTER).getAccounts().get(BankingUtility.ACCOUNT_NO_COUNTER).getTransactions().put(BankingUtility.TRANSACTION_ID_COUNTER,new Transaction(20000, "cheque"));
	}
	@Test
	public void testAcceptCustomerDetailsForValidData(){
		int expectedId=112;
		Customer actualcustomerId=new Customer(BankingUtility.CUSTOMER_ID_COUNTER,"Sindhu", "Pullela", "sindhu@abc.com", "djfu", new Address(1323, "crl", "Ap"), new Address(1343, "Hyd", "tel"));
		BankingDAOServicesImpl.customers.put(BankingUtility.CUSTOMER_ID_COUNTER++,actualcustomerId);
		Assert.assertEquals(expectedId, actualcustomerId.getCustomerId());
	}
	@Test
	public void testGetCustomerDetailsForValidData()throws CustomerNotFoundException,BankingServicesDownException{
		Customer customer1=new Customer("Sindhu", "Pullela", "sindhu@abc.com", "dfhsuh", new Address(135, "Crl", "Ap"), new Address(133, "Hyd", "tel"));
		Assert.assertEquals(customer1.getCustomerId(),bankingServices.getCustomerDetails(111).getCustomerId());
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerDetailsForInvalidData()throws CustomerNotFoundException,BankingServicesDownException{
		Assert.assertEquals(112, bankingServices.getCustomerDetails(114));
		
	}
	@Test
	public void testGetAccountDetailsForValidData()throws AccountNotFoundException,BankingServicesDownException,CustomerNotFoundException{
		Account account1=new Account(123, 0, "Savings", "Active", 500, 122435);
		Assert.assertEquals(account1, bankingServices.getAccountDetails(112,122435));
	}
	@Test
	public void testGetAllCustomerDetails() throws CustomerNotFoundException,BankingServicesDownException{
		bankingServices.getAllCustomerDetails();
	}
	@Test
	public void testGetCutomerAllAccountDetails()throws CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException{
		bankingServices.getcustomerAllAccountDetails();
	}
	@Test
	public void testOpenAccountForValidData()throws InvalidAccountTypeException,InvalidAmountException,CustomerNotFoundException,BankingServicesDownException{
		Assert.assertEquals(11111112,bankingServices.openAccount(112, "Savings", 500));
	}
	@Test
	public void testOpenAccountForInvalidData()throws InvalidAccountTypeException,InvalidAmountException,CustomerNotFoundException,BankingServicesDownException{
	Assert.assertEquals(11111112, bankingServices.openAccount(119, "Savings", 0));
	}
		@Test
	public void testGetAccountAllTransaction()throws CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException{
		bankingServices.getAccountAllTransaction();
	}
	@After
	public void tearDownMockData(){
		BankingDAOServicesImpl.customers.clear();
	}
	@AfterClass
	public static void setUp(){
		
	}
	}
