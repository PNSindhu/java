package com.cg.banking.daoservices;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.utility.BankingUtility;

public class BankingDAOServicesImpl implements BankingDAOServices {
	public static HashMap<Integer,Customer>customers=new HashMap<Integer,Customer>();
	private static Random random=new Random();	
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		customers.put(customer.getCustomerId(),customer);
		return customer.getCustomerId();
	} 

	public boolean updateCustomer(Customer customer) {
		customers.put(customer.getCustomerId(),customer);
				return true;
			}


	public boolean deleteCustomer(int customerID) {
		customers.remove(customerID);
				return true;
			}
	@Override
	public long insertAccount(int customerId, Account account) {
		customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_NO_COUNTER,account);
		customers.get(customerId).getAccounts().get(BankingUtility.ACCOUNT_NO_COUNTER).setAccountNo(BankingUtility.ACCOUNT_NO_COUNTER++);;
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		if(customers.containsKey(customerId)==true){
		if(customers.get(customerId).getAccounts().containsKey(account.getAccountNo())==true)	{
		customers.get(customerId).getAccounts().put(BankingUtility.ACCOUNT_NO_COUNTER,account);
		customers.get(customerId).getAccounts().get(BankingUtility.ACCOUNT_NO_COUNTER).setAccountNo(BankingUtility.ACCOUNT_NO_COUNTER++);
		return true;
		}
	}
			return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		getcustomer(customerId).getAccounts().get(account.getAccountNo()).setPinNumber(random.nextInt(10000));
		return account.getPinNumber();
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		if(getAccount(customerId, accountNo)==null)
			return false;
		customers.get(customerId).getAccounts().get(accountNo).getTransactions().put(getAccount(customerId,accountNo).getTRANSACTION_ID_COUNTER(),transaction);			
		customers.get(customerId).getAccounts().get(accountNo).getTransactions().get(getAccount(customerId,accountNo).getTRANSACTION_ID_COUNTER()).setTransactionId(getAccount(customerId,accountNo).getTRANSACTION_ID_COUNTER()+1);			
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		customers.get(customerId).getAccounts().remove(accountNo);					
				return true;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		Account a=customers.get(customerId).getAccounts().get(accountNo);
		if(a==null)
			return null;
		return a;
			}

	@Override
	public List<Account> getAccounts(int customerId) {
		return new ArrayList<>(getCustomer(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId,accountNo).getTransactions().values());
	}

	@Override
	public List<Customer> getCustomers() {
		return new ArrayList<>(customers.values());
	}

	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);

	}

	@Override
	public Customer getcustomer(int customerId) {
		return null;
	}

	@Override
	public Customer[] getcustomer() {
		return null;
	}

	public float balanceEnquiry(int customerId, long accountNo, int pinNumber) {
		// TODO Auto-generated method stub
		return 0;
	}
	
		}






	


