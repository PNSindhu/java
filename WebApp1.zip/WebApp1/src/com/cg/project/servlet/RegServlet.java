package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class RegServlet
 */
@WebServlet("/RegServlet")
public class RegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegServlet() {
        super();
    }
    @Override
	public void destroy() {
		System.out.println("destroy()");
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig config)");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("service()");
		String firstName=request.getParameter("firstName");
		String lastName= request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String password= request.getParameter("password");
		String ReenterPassword=request.getParameter("reenterPassword");
		String EmailID=request.getParameter("emailId");
		String MobileNumber= request.getParameter("mobileNumber");
		String Gender=request.getParameter("gender");
		String Communication= request.getParameter("communication");
		String Graduation=request.getParameter("graduation");
		String Enteraboutu= request.getParameter("enter about u");
		String FileName =request.getParameter("fileName");
		PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("Registartion Page");
		writer.println("</br>");
		writer.println("FirstName:"+firstName);
		writer.println("</br>");
		writer.println("LastName:"+lastName);
		writer.println("</br>");
		writer.println("UserName:"+userName);
		writer.println("</br>");
		writer.println("Password:"+password);
		writer.println("</br>");
		writer.println("Reenter Password:"+ReenterPassword);
		writer.println("</br>");
		writer.println("EmailId:"+EmailID);
		writer.println("</br>");
		writer.println("MobileNumber:"+MobileNumber);
		writer.println("</br>");
		writer.println("Gender:"+Gender);
		writer.println("</br>");
		writer.println("Communication:"+Communication);
		writer.println("</br>");
		writer.println("Graduation:"+Graduation);
		writer.println("Enter about u:"+Enteraboutu);
		writer.println("</br>");
		writer.println("FileName:"+FileName);
		writer.println("</body>");
		writer.println("</head>");
		writer.println("</html>");
		}
}