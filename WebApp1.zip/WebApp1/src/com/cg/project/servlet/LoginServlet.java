package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private Connection con;
    public LoginServlet() {
        super();
    }

	public void init(ServletConfig config) throws ServletException  {
		System.out.println("init(ServletConfig config");
		ServletContext servletcontext=getServletContext();
		 con = (Connection)servletcontext.getAttribute("con");

	}

	
	public void destroy() {
		System.out.println("destroy()");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 try{
		 PrintWriter writer=response.getWriter();
		 String userName=request.getParameter("userName");
			String password= request.getParameter("password");
			String errorMessage;
			RequestDispatcher dispatcher;
			UserBean userBean=new UserBean();
			PreparedStatement pstmt=con.prepareStatement("Select password from UserBean where username=?");
			pstmt.setString(1, userBean.getUserName());
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()){
				if(rs.getString("password").equals(userBean.getPassword())){
			
				dispatcher=request.getRequestDispatcher("SuccessPage.jsp");
				request.setAttribute("userName",userName);
				request.setAttribute("password", password);
				dispatcher.forward(request, response);
			}
	 }
			
	 else
	 {
		 dispatcher=request.getRequestDispatcher("ErrorPage.jsp");
			request.setAttribute("errorMessage","UserName or password wrong pls try again");
			dispatcher.forward(request, response);
		}
	 }catch(SQLException e){
		 e.printStackTrace();
	 }
	} 
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("service()");
		doPost(request,response);
	}
	}
		/*String userName=request.getParameter("userName");
		String password= request.getParameter("password");
		String errorMessage;
		RequestDispatcher dispatcher;
		UserBean userBean=new UserBean(userName,password);
		if(userBean.getUserName().equals("Sindhu")&&userBean.getPassword().equals("sisisisi")){
		if((userName.equals("sindhu")&&password.equals("helloworld"))){

			dispatcher=request.getRequestDispatcher("SuccessPage.jsp");
			request.setAttribute("userName",userName);
			request.setAttribute("password", password);
			dispatcher.forward(request, response);
		}
		else{
			dispatcher=request.getRequestDispatcher("ErrorPage.jsp");
			request.setAttribute("errorMessage","UserName or password wrong pls try again");
			dispatcher.forward(request, response);
		}
	}
}
		/*PrintWriter writer=response.getWriter();
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<body>");
		writer.println("<div align='center'>");
		writer.println("Welcome");
		writer.println("<br/>");
		writer.println("username:"+userName);
		writer.println("<br/>");
		writer.println("password:"+password);
			if((userName.equals("sisisisi")&&password.equals("helloworld"))){
		writer.println("<font color='green' size=10>");
		}
	else{
	writer.println("<font color='red' size=10>");
	}
			writer.println("</body>");
			writer.println("</head>");
			writer.println("</html>");
		
		
		}	
	}*/



