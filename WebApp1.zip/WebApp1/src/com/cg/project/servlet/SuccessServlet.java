package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public SuccessServlet() {
        super();
    }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig config");

	}

	public void destroy() {
		System.out.println("destroy()");
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String userName=(String)request.getAttribute("userName");
	String password=(String) request.getAttribute("password");
	PrintWriter writer=response.getWriter();
	writer.println("<html>");
	writer.println("<head>");
	writer.println("<body>");
	writer.println("<div align='center'>");
	writer.println("Welcome");
	writer.println("<br/>");
	writer.println("username:"+userName);
	writer.println("<br/>");
	writer.println("password:"+password);
	writer.println("</body>");
	writer.println("</head>");
	writer.println("</html>");

	}

}
