package com.cg.project.collections;

import java.util.ArrayList;

public class MainClass {

	public static void main(String[] args) {
		MyGenericType<String> strlist=new MyGenericType<String>("Hello", "world");
		ArrayList<String> strList=new ArrayList<>();
		strList.add("abc");
		strList.add("cdf");
		iterateOutList(strList);
		MyGenericType<Integer> intlist=new MyGenericType<Integer>(10, 20);
		ArrayList<Integer> intList=new ArrayList<>();
		intList.add(10);
		intList.add(20);
		iterateOutList(intList);
}
	private static void iterateOutList(ArrayList<?> elements) {
		
		}
	}
