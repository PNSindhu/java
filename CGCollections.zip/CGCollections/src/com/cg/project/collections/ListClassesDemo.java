package com.cg.project.collections;
import java.util.Iterator;
import com.cg.project.beans.Customer;
import java.util.ArrayList;
import java.util.Collections;

public class ListClassesDemo {
	private static ArrayList<String>;

	public static void arrayListClassWork(){
		ArrayList<String> strList=new ArrayList<>();
		//insert
		strList.add("Sindhu");
		strList.add("Sindhu");
		strList.add(0,"chakri");
		strList.add("Deepu");
		strList.add("Hari");
		strList.add("Indira");
		strList.add("chinnu");
		strList.add("Chintu");
		//iteration
		Iterator<String> iterator=strList.iterator();
		while(iterator.hasNext()){
			String string=iterator.next();
			intList.add(111);
			intList.add(123);
			intList.add(113);
			intList.add(105);
			intList.add(107);
			
			Collections.sort(intList);
			ArrayList<Customer>customerList=new ArrayList<>();
			System.out.println(new Customer(111,"sindhu","Pullela"));
			System.out.println(new Customer(113,"Chakri","Pullela"));
			System.out.println(new Customer(114,"Hari","Pullela"));
			System.out.println(new Customer(115,"Indira","Pullela"));
			
			Customer  customerToBeSearche=new Customer(113,"chakri","Pullela");
			System.out.println(customerList.contains(customerToBeSearch);
			Collections.sort(customerList);
			Collections.sort(customerList,new CustomerCompartor());
			for(Customer customer:customerList){
				System.out.println(customer);
			}			

			
		}
		
	}

}
