package com.cg.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;

import junit.framework.Assert;

public class LoginPageTest {
	
 static WebDriver driver;
 private LoginPage loginPage;
 @BeforeClass
 public static void setUpDriverEnv(){
	System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
 	driver=new ChromeDriver();
 	driver.manage().window().maximize();
 }
 @Before
 public void setUpTest(){
	 driver.get("https://github.com/login");
	 loginPage=new LoginPage();
	 PageFactory.initElements(driver, loginPage);
	 
 }
 @Test
 public void testForBlankUserNameAndPassword(){
	 loginPage.setUsername("");
	 loginPage.setPassword("");
	 loginPage.clickSubmitButton();
	 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='container']")).getText();
	 String expectedErrorMessage="Incorrect username and password";
	 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
	  }
 @Test
 public void testForBlankUserNameAndCorrectPassword(){
	 loginPage.setUsername("");
	 loginPage.setPassword("myfamily1");
	 loginPage.clickSubmitButton();
	 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='container']")).getText();
	 String expectedErrorMessage="Incorrect username and password";
	 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
 }
 @Test
 public void testForCorrectUserNameAndBlankPassword(){
	 loginPage.setUsername("PNSindhu");
	 loginPage.setPassword("");
	 loginPage.clickSubmitButton();
	 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='container']")).getText();
	 String expectedErrorMessage="Incorrect username and password";
	 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
 }
 @Test
 public void testForCorrectUserNameAndPassword(){
	 loginPage.setUsername("PNSindhu");
	 loginPage.setPassword("myfamily1");
	 loginPage.clickSubmitButton();
	 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='container']")).getText();
	 String expectedErrorMessage="Incorrect username and password";
	 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
 }

 
@After
public void setDownTest(){
loginPage=null;
}
@AfterClass
public static void setDownDriverEnv(){
	driver.close();
}

}
