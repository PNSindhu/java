package com.cg.project;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;
import com.cg.project.beans.RegistrationPage;

import junit.framework.Assert;

public class RegistrationPageTest {
	static WebDriver driver;
	 private RegistrationPage registrationPage;
	 @BeforeClass
	 public static void setUpDriverEnv(){
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
	 	driver=new ChromeDriver();
	 	driver.manage().window().maximize();
	 }
	 @Before
	 public void setUpTest(){
		 driver.get("https://github.com/join?source=header-home");
		 registrationPage=new RegistrationPage();
		 PageFactory.initElements(driver, registrationPage);
	}
	 @Test
	 public void testForBlankUserNameAndPasswordAndEmailID(){
		 registrationPage.setUsername("");
		 registrationPage.setPassword("");
		 registrationPage.setemailID("");
		 registrationPage.clickSubmitButton();

		 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash']")).getText();
		 String expectedErrorMessage="Incorrect username and password";
		 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
	 }
		 @Test
		 public void testForBlankUserNameAndPasswordAndcorrectEmailID(){
			 registrationPage.setUsername("");
			 registrationPage.setPassword("");
			 registrationPage.setemailID("sindhupullela207@capgemini.com");
			 registrationPage.clickSubmitButton();

			 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash']")).getText();
			 String expectedErrorMessage="Incorrect username and password";
			 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
		 }
		 @Test
		 public void testForBlankUserNameAndemailIDAndvalidPassword(){
			 registrationPage.setUsername("");
			 registrationPage.setPassword("myfamily4");
			 registrationPage.setemailID("");
			 registrationPage.clickSubmitButton();

			 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash']")).getText();
			 String expectedErrorMessage="Incorrect username and password";
			 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
		 }
				 @Test
		 public void testForValidUserNameAndBlankEmailIDAndPassword(){
			 registrationPage.setUsername("PNSindhuB");
			 registrationPage.setPassword("");
			 registrationPage.setemailID("");
			 registrationPage.clickSubmitButton();

			 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash']")).getText();
			 String expectedErrorMessage="Incorrect username and password";
			 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
		 }
				 @Test
				 public void testForValidUserNameAndEmailIDAndPassword(){
					 registrationPage.setUsername("PNSindhuB");
					 registrationPage.setPassword("myfamily4");
					 registrationPage.setemailID("sindhupullela207@capgemini.com");
					 registrationPage.clickSubmitButton();

					 String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash']")).getText();
					 String expectedErrorMessage="Incorrect username and password";
					 Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
				 }



	 @After
	 public void setDownTest(){
	 registrationPage=null;
	 }
	 @AfterClass
	 public static void setDownDriverEnv(){
	 	driver.close();
	 }

}
