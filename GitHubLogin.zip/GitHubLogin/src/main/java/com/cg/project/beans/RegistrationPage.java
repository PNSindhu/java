package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage {
	@FindBy(id="user_login")
	WebElement username;
	
	@FindBy(id="user_password")
	WebElement password;
	
	@FindBy(id="user_email")
	WebElement emailID;
	
	@FindBy(className="btn")
	WebElement button;

	public RegistrationPage() {
		super();
	}
	
	public void setUsername(String username){
		this.username.sendKeys(username);
	}
	public void setemailID(String emailID){
		this.emailID.sendKeys(emailID);
	}
	
	public WebElement getPassword(){
		return password;
	}
	public void setPassword(String password){
		this.password.sendKeys(password);
	}
	public void clickSubmitButton(){
		button.submit();
	}
	
	
}
